package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entity.theatre;

public interface theatre_repo extends JpaRepository<theatre, String> {

}
